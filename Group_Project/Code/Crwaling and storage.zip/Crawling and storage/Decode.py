import base64
from fontTools.ttLib import TTFont
import re
import requests
import random
from io import BytesIO

def generate_headers():
    head_connection = ['Keep-Alive', 'close']
    head_accept = ['text/html,application/xhtml+xml,*/*']
    head_accept_language = ['zh-CN,fr-FR;q=0.5', 'en-US,en;q=0.8,zh-Hans-CN;q=0.5,zh-Hans;q=0.3']
    head_accept_encoding = ['gzip']
    head_user_agent = ['Mozilla/5.0 (Windows NT 6.3; WOW64; Trident/7.0; rv:11.0) like Gecko',
                       'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/28.0.1500.95 Safari/537.36',
                       'Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; .NET4.0C; rv:11.0) like Gecko)',
                       'Mozilla/5.0 (Windows; U; Windows NT 5.2) Gecko/2008070208 Firefox/3.0.1',
                       'Mozilla/5.0 (Windows; U; Windows NT 5.1) Gecko/20070309 Firefox/2.0.0.3',
                       'Mozilla/5.0 (Windows; U; Windows NT 5.1) Gecko/20070803 Firefox/1.5.0.12',
                       'Opera/9.27 (Windows NT 5.2; U; zh-cn)',
                       'Mozilla/5.0 (Macintosh; PPC Mac OS X; U; en) Opera 8.0',
                       'Opera/8.0 (Macintosh; PPC Mac OS X; U; en)',
                       'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.12) Gecko/20080219 Firefox/2.0.0.12 Navigator/9.0.0.6',
                       'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Win64; x64; Trident/4.0)',
                       'Mozilla/4.0 (compatible; MSIE 8.0; Windows NT 6.1; Trident/4.0)',
                       'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.2; .NET4.0C; .NET4.0E)',
                       'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Maxthon/4.0.6.2000 Chrome/26.0.1410.43 Safari/537.1 ',
                       'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0; SLCC2; .NET CLR 2.0.50727; .NET CLR 3.5.30729; .NET CLR 3.0.30729; Media Center PC 6.0; InfoPath.2; .NET4.0C; .NET4.0E; QQBrowser/7.3.9825.400)',
                       'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:21.0) Gecko/20100101 Firefox/21.0 ',
                       'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/21.0.1180.92 Safari/537.1 LBBROWSER',
                       'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.1; WOW64; Trident/6.0; BIDUBrowser 2.x)',
                       'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.11 TaoBrowser/3.0 Safari/536.11']
    headers = {
    			'Connection': head_connection[random.randrange(0, len(head_connection))],
				'Accept': head_accept[0],
				'Accept-Language': head_accept_language[random.randrange(0, len(head_accept_language))],
				'Accept-Encoding': head_accept_encoding[0],
				'User-Agent': head_user_agent[random.randrange(0, len(head_user_agent))]
    }
    return headers

class Decode:
    def __init__(self):
        self.base64_str = None
        self.filePath01 = r'jiemi_20190402_03.otf'
        # self.filePath02 = r'text_20190402_03.xml'
        self.uniList = None
        self.utfList = None
    def refresh(self,reponse):
        self.base64_str = re.findall("charset=utf-8;base64,(.*?)'\)", reponse.text)[0]
        binData = base64.decodebytes(self.base64_str.encode())
        # 写入otf字体文件
        with open(self.filePath01, 'wb') as f:
            f.write(binData)
            f.close()
        # 解析字体库
        #font01 = TTFont(self.filePath01)
        # BytesIO() 把二进制数据bin_data当作文件来操作,TTFont接收一个文件类型
        font01 = TTFont(BytesIO(binData))
        self.uniList = font01['cmap'].tables[0].ttFont.getGlyphOrder()
        self.utfList = font01['cmap'].tables[0].ttFont.tables['cmap'].tables[0].cmap  # c = font.getBestCmap()
    def convert_text(self,getText):
        retList = []
        for i in getText:
            # ord()以字符作为参数，返回对应的Unicode数值
            if ord(i) in self.utfList:
                #print (self.utfList[ord(i)])
                text = int(self.utfList[ord(i)][-2:]) - 1
            else:
                text = i
            retList.append(text)
        crackText = ''.join([str(i) for i in retList])
        return crackText

#decode = Decode()
#decode.refresh("https://sz.zu.anjuke.com/")
#print (decode.convert_text(getText))